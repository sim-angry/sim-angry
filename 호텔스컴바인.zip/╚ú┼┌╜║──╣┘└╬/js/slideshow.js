var slides = document.querySelectorAll("#slides > img");
var prev = document.getElementById("prev");
var next = document.getElementById("next");
var current = 0;

showSlides(current);
prev.onclick = prevSlide;
next.onclick = nextSlide;

function showSlides(n) {
  for (let i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slides[n].style.display = "block";
}

function prevSlide() {
  if (current > 0) current -= 1;
  else current = slides.length - 1;
  showSlides(current);
}

function nextSlide() {
  if (current < slides.length - 1) current += 1;
  else current = 0;
  showSlides(current);
}

let checks = document.querySelector(".question1");
checks.addEventListener("click", function () {
  window.open("hotel1.html", "popup", "width=750, height=600");
});

let checks1 = document.querySelector(".question2");
checks1.addEventListener("click", function () {
  window.open("hotel1.html", "popup", "width=750, height=600");
});

let checks2 = document.querySelector(".question3");
checks2.addEventListener("click", function () {
  window.open("hotel2.html", "popup", "width=750, height=600");
});

let checks3 = document.querySelector(".question4");
checks3.addEventListener("click", function () {
  window.open("hotel2.html", "popup", "width=750, height=600");
});

